import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nyyyxyz Qur'an — Al-Qur'an Digital",
  description: "Baca, dengarkan, dan pelajari Al-Qur'an dengan nyaman. Dikembangkan oleh Nyyyxyz.",
  applicationName: "Nyyyxyz Qur'an",
  manifest: "/manifest.json",
  icons: { icon: "/icon.svg" },
  openGraph: {
    title: "Nyyyxyz Qur'an",
    description: "Al-Qur'an digital yang nyaman dibaca di mana saja.",
    type: "website"
  }
};

export const viewport: Viewport = {
  themeColor: "#0d3329",
  width: "device-width",
  initialScale: 1
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
