 "use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  BookOpen, Bookmark, Clock3, Headphones, Search, Moon, Sun, Menu, X,
  Heart, ExternalLink, Play, Pause, ChevronRight, ChevronLeft, Home,
  Settings2, ListMusic, Sparkles, Copy, Check, Volume2
} from "lucide-react";

type Surah = {
  nomor: number; nama: string; namaLatin: string; jumlahAyat: number;
  tempatTurun: string; arti: string; deskripsi?: string;
};
type Ayah = {
  nomorAyat: number; teksArab: string; teksLatin: string; teksIndonesia: string;
  audio?: Record<string, string>;
};
type SurahDetail = Surah & { ayat: Ayah[]; audioFull?: Record<string, string> };

const API = "https://equran.id/api/v2";
const CHANNEL = "https://whatsapp.com/channel/0029Vb7sYxYHbFV4BleXsV1J";
const qaris = [
  { id: "01", name: "Abdullah Al-Juhany" },
  { id: "02", name: "Abdul Muhsin Al-Qasim" },
  { id: "03", name: "Abdurrahman As-Sudais" },
  { id: "04", name: "Ibrahim Al-Dossari" },
  { id: "05", name: "Misyari Rasyid Al-Afasy" },
  { id: "06", name: "Yasser Al-Dosari" }
];

export default function HomePage() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selected, setSelected] = useState<SurahDetail | null>(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [readerLoading, setReaderLoading] = useState(false);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"home" | "bookmarks">("home");
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [lastRead, setLastRead] = useState<{ surah: number; ayah: number } | null>(null);
  const [dark, setDark] = useState(false);
  const [showLatin, setShowLatin] = useState(true);
  const [showTranslation, setShowTranslation] = useState(true);
  const [fontSize, setFontSize] = useState(32);
  const [qari, setQari] = useState("05");
  const [playing, setPlaying] = useState(false);
  const [audioUrl, setAudioUrl] = useState("");
  const [activeAyah, setActiveAyah] = useState<number | null>(null);
  const [showDonate, setShowDonate] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [copied, setCopied] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  useEffect(() => {
    try {
      setBookmarks(JSON.parse(localStorage.getItem("nyyyxyz-bookmarks") || "[]"));
      setLastRead(JSON.parse(localStorage.getItem("nyyyxyz-lastread") || "null"));
      setDark(localStorage.getItem("nyyyxyz-theme") === "dark");
    } catch {}
    fetch(`${API}/surat`)
      .then(r => { if (!r.ok) throw new Error("Gagal mengambil data surah."); return r.json(); })
      .then(j => setSurahs(j.data || []))
      .catch(() => setError("Data Al-Qur'an belum dapat dimuat. Periksa koneksi internet lalu coba lagi."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    localStorage.setItem("nyyyxyz-bookmarks", JSON.stringify(bookmarks));
  }, [bookmarks]);
  useEffect(() => {
    localStorage.setItem("nyyyxyz-theme", dark ? "dark" : "light");
  }, [dark]);
  useEffect(() => {
    if (audioRef.current && audioUrl) {
      audioRef.current.src = audioUrl;
      if (playing) audioRef.current.play().catch(() => setPlaying(false));
    }
  }, [audioUrl, playing]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = tab === "bookmarks"
      ? surahs.filter(s => bookmarks.some(b => b.startsWith(`${s.nomor}:`)))
      : surahs;
    return !q ? list : list.filter(s =>
      s.namaLatin.toLowerCase().includes(q) || s.arti.toLowerCase().includes(q) ||
      s.nomor.toString() === q || s.nama.includes(query.trim())
    );
  }, [surahs, query, tab, bookmarks]);

  async function openSurah(number: number, ayah = 1) {
    setReaderLoading(true); setError(""); setSelected(null); setTab("home");
    try {
      const res = await fetch(`${API}/surat/${number}`);
      if (!res.ok) throw new Error();
      const json = await res.json();
      setSelected(json.data);
      const progress = { surah: number, ayah };
      setLastRead(progress);
      localStorage.setItem("nyyyxyz-lastread", JSON.stringify(progress));
      setTimeout(() => document.getElementById(`ayah-${ayah}`)?.scrollIntoView({ behavior: "smooth", block: "center" }), 250);
    } catch {
      setError("Surah gagal dimuat. Silakan coba kembali.");
    } finally { setReaderLoading(false); }
  }

  function toggleBookmark(surah: number, ayah: number) {
    const key = `${surah}:${ayah}`;
    setBookmarks(prev => prev.includes(key) ? prev.filter(x => x !== key) : [...prev, key]);
  }

  function playFull() {
    const url = selected?.audioFull?.[qari];
    if (!url) return;
    if (playing) { audioRef.current?.pause(); setPlaying(false); }
    else { setAudioUrl(url); setPlaying(true); }
  }

  function playAyah(ayah: Ayah) {
    const url = ayah.audio?.[qari];
    if (!url) return;
    setActiveAyah(ayah.nomorAyat);
    setAudioUrl(url); setPlaying(true);
  }

  async function shareAyah(ayah: Ayah) {
    const text = `${selected?.namaLatin} ayat ${ayah.nomorAyat}\n${ayah.teksArab}\n${ayah.teksIndonesia}`;
    try {
      if (navigator.share) await navigator.share({ title: "Nyyyxyz Qur'an", text });
      else { await navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1800); }
    } catch {}
  }

  const isBookmarked = (s: number, a: number) => bookmarks.includes(`${s}:${a}`);

  return (
    <main className={dark ? "app dark" : "app"}>
      <header className="topbar">
        <button className="brand" onClick={() => { setSelected(null); setTab("home"); }} aria-label="Beranda">
          <span className="brand-mark">ن</span>
          <span><b>NYYYXYZ</b><small>QUR'AN DIGITAL</small></span>
        </button>
        <nav className="desktop-nav">
          <button className={!selected && tab === "home" ? "nav-active" : ""} onClick={() => {setSelected(null);setTab("home");}}>Beranda</button>
          <button onClick={() => {setSelected(null);setTab("bookmarks");}}>Tersimpan</button>
          <a href={CHANNEL} target="_blank" rel="noreferrer">Saluran <ExternalLink size={14}/></a>
        </nav>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => setDark(!dark)} aria-label="Ganti tema">{dark ? <Sun/> : <Moon/>}</button>
          <button className="donate-small" onClick={() => setShowDonate(true)}><Heart size={15}/> Donasi</button>
          <button className="icon-btn mobile-only" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Menu">{mobileMenu ? <X/> : <Menu/>}</button>
        </div>
      </header>

      {mobileMenu && <div className="mobile-menu"><button onClick={() => {setSelected(null);setTab("home");setMobileMenu(false);}}>Beranda</button><button onClick={() => {setSelected(null);setTab("bookmarks");setMobileMenu(false);}}>Tersimpan</button><a href={CHANNEL} target="_blank" rel="noreferrer">Ikuti Saluran WhatsApp</a></div>}

      {!selected ? (
        <div className="page-wrap">
          <section className="hero">
            <div className="hero-copy">
              <span className="eyebrow"><Sparkles size={14}/> TEMAN IBADAH HARIAN</span>
              <h1>Tenangkan hati,<br/><em>dekatkan diri</em> dengan Al-Qur'an.</h1>
              <p>Baca, pahami, dan dengarkan ayat suci Al-Qur'an kapan saja dengan pengalaman yang nyaman dan sederhana.</p>
              <button className="primary-btn" onClick={() => openSurah(lastRead?.surah || 1, lastRead?.ayah || 1)}><BookOpen size={17}/> {lastRead ? "Lanjutkan membaca" : "Mulai membaca"} <ChevronRight size={17}/></button>
            </div>
            <div className="hero-art">
              <div className="orb orb-one"/><div className="orb orb-two"/>
              <div className="arch"><div className="arch-inner"><span className="bismillah">﷽</span><span className="arch-caption">AL-QUR'AN AL-KARIM</span><span className="arch-line"/></div></div>
              <span className="hero-leaf">۞</span>
            </div>
            <div className="hero-bottom"><span>ٱلَّذِينَ آمَنُوا۟ وَتَطْمَئِنُّ قُلُوبُهُم بِذِكْرِ ٱللَّهِ</span><small>Ingatlah, hanya dengan mengingat Allah hati menjadi tenteram. · QS. Ar-Ra'd: 28</small></div>
          </section>

          <section className="quick-grid">
            <button className="quick-card" onClick={() => openSurah(1)}><span className="quick-icon"><BookOpen/></span><span><b>Baca Al-Qur'an</b><small>114 surah · 30 juz</small></span><ChevronRight/></button>
            <button className="quick-card" onClick={() => setTab("bookmarks")}><span className="quick-icon"><Bookmark/></span><span><b>Ayat tersimpan</b><small>{bookmarks.length} ayat favorit</small></span><ChevronRight/></button>
            <button className="quick-card" onClick={() => lastRead && openSurah(lastRead.surah, lastRead.ayah)}><span className="quick-icon"><Clock3/></span><span><b>Terakhir dibaca</b><small>{lastRead ? `Surah ${lastRead.surah}, ayat ${lastRead.ayah}` : "Belum ada riwayat"}</small></span><ChevronRight/></button>
          </section>

          <section className="surah-section">
            <div className="section-heading"><div><span className="eyebrow">JELAJAHI KITAB SUCI</span><h2>{tab === "bookmarks" ? "Ayat tersimpan" : "Daftar Surah"}</h2><p>Pilih surah untuk mulai membaca.</p></div><div className="surah-count">{surahs.length || "—"} <small>SURAH</small></div></div>
            <div className="search-row"><div className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Cari nama surah, arti, atau nomor..."/>{query && <button onClick={() => setQuery("")}><X size={16}/></button>}</div><button className="filter-btn" onClick={() => setTab(tab === "home" ? "bookmarks" : "home")}><Bookmark size={16}/>{tab === "home" ? "Tersimpan" : "Semua surah"}</button></div>
            {loading ? <div className="loading-grid">{Array.from({length:8}).map((_,i)=><div className="skeleton" key={i}/>)}</div> :
              error && !surahs.length ? <div className="empty-state">{error}<button onClick={() => location.reload()}>Muat ulang</button></div> :
              filtered.length ? <div className="surah-grid">{filtered.map(s => <button className="surah-card" key={s.nomor} onClick={() => openSurah(s.nomor)}>
                <span className="surah-number">{String(s.nomor).padStart(3,"0")}</span><span className="surah-info"><b>{s.namaLatin}</b><small>{s.arti} · {s.jumlahAyat} ayat</small></span><span className="surah-arabic">{s.nama}</span>
              </button>)}</div> : <div className="empty-state">{tab === "bookmarks" ? "Belum ada ayat yang disimpan." : "Surah tidak ditemukan."}</div>}
          </section>
        </div>
      ) : (
        <div className="reader-wrap">
          <div className="reader-toolbar"><button className="back-btn" onClick={() => setSelected(null)}><ChevronLeft size={18}/> Daftar surah</button><div className="reader-tools"><label className="select-wrap"><Headphones size={16}/><select value={qari} onChange={e => setQari(e.target.value)}>{qaris.map(q=><option key={q.id} value={q.id}>{q.name}</option>)}</select></label><button className="icon-btn" onClick={() => setShowLatin(!showLatin)} title="Tampilkan latin">Aa</button><button className="icon-btn" onClick={() => setShowTranslation(!showTranslation)} title="Tampilkan terjemahan"><Settings2/></button></div></div>
          <section className="surah-title-card"><span className="eyebrow">{selected.tempatTurun?.toUpperCase()} · SURAH KE-{selected.nomor}</span><h1>{selected.namaLatin}</h1><div className="surah-title-arabic">{selected.nama}</div><p>{selected.arti} · {selected.jumlahAyat} ayat</p><button className="primary-btn audio-main" onClick={playFull}>{playing ? <Pause size={17}/> : <Play size={17}/>} {playing ? "Jeda murottal" : "Putar satu surah"} <Volume2 size={17}/></button></section>
          <div className="reader-settings"><span><BookOpen size={16}/> Tampilan bacaan</span><div><button onClick={() => setFontSize(v => Math.max(24,v-2))}>A−</button><b>{fontSize}</b><button onClick={() => setFontSize(v => Math.min(52,v+2))}>A+</button></div></div>
          <div className="ayah-list">{selected.ayat?.map(a => <article className={`ayah-card ${activeAyah === a.nomorAyat ? "ayah-playing" : ""}`} id={`ayah-${a.nomorAyat}`} key={a.nomorAyat}>
            <div className="ayah-top"><span className="ayah-number">{selected.nomor}:{a.nomorAyat}</span><div className="ayah-actions"><button onClick={() => playAyah(a)} title="Putar ayat">{activeAyah === a.nomorAyat && playing ? <Pause size={17}/> : <Play size={17}/>}</button><button onClick={() => toggleBookmark(selected.nomor,a.nomorAyat)} title="Simpan ayat"><Bookmark size={17} fill={isBookmarked(selected.nomor,a.nomorAyat) ? "currentColor" : "none"}/></button><button onClick={() => shareAyah(a)} title="Bagikan ayat">{copied ? <Check size={17}/> : <Copy size={17}/>}</button></div></div>
            <p className="arabic-text" style={{fontSize}} dir="rtl">{a.teksArab}</p>
            {showLatin && <p className="latin-text">{a.teksLatin}</p>}
            {showTranslation && <p className="translation-text">{a.teksIndonesia}</p>}
          </article>)}</div>
          <div className="surah-pagination"><button disabled={selected.nomor===1} onClick={() => openSurah(selected.nomor-1)}><ChevronLeft/> Sebelumnya</button><button disabled={selected.nomor===114} onClick={() => openSurah(selected.nomor+1)}>Selanjutnya <ChevronRight/></button></div>
        </div>
      )}

      <footer className="footer"><div className="footer-brand"><span className="brand-mark">ن</span><span><b>NYYYXYZ QUR'AN</b><small>Menemani langkah kebaikan.</small></span></div><div className="footer-links"><a href={CHANNEL} target="_blank" rel="noreferrer">Ikuti Saluran <ExternalLink size={13}/></a><button onClick={() => setShowDonate(true)}>Donasi developer <Heart size={13}/></button></div><p>Dikembangkan oleh <b>Nyyyxyz / Kenny</b> · Data Al-Qur'an dari EQuran.id (sumber Kemenag RI).</p><small>© {new Date().getFullYear()} Nyyyxyz. Dibuat dengan niat baik.</small></footer>

      {showDonate && <div className="modal-backdrop" onClick={() => setShowDonate(false)}><section className="donate-modal" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setShowDonate(false)}><X/></button><span className="eyebrow">DUKUNG PENGEMBANGAN</span><h2>Donasi seikhlasnya</h2><p>Jika website ini bermanfaat, kamu dapat mendukung pengembangannya melalui QRIS berikut. Terima kasih atas dukungannya.</p><img src="/qris-nyyyxyz.png" alt="QRIS donasi Nyyyxyz" className="qris-image"/><b className="donate-name">NyyyxyzXvyeraaa</b><small>Scan menggunakan aplikasi pembayaran yang mendukung QRIS.</small><button className="primary-btn modal-done" onClick={() => setShowDonate(false)}>Selesai</button></section></div>}
      <audio ref={audioRef} onEnded={() => setPlaying(false)} onPause={() => setPlaying(false)} onPlay={() => setPlaying(true)} />
      {readerLoading && <div className="loading-overlay"><div className="spinner"/><span>Menyiapkan ayat suci...</span></div>}
    </main>
  );
}
